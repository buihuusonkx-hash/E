# Trợ Lý Giáo Án Số 4.0

Ứng dụng hỗ trợ giáo viên tích hợp năng lực số và AI vào giáo án, hỗ trợ công thức toán học và xuất file Word.

## Triển khai lên Vercel / GitHub

1. **GitHub:** Đẩy toàn bộ mã nguồn lên kho lưu trữ GitHub của bạn.
2. **Vercel:** 
   - Kết nối tài liệu GitHub với Vercel.
   - **Quan trọng:** Trong phần **Environment Variables** trên Vercel, hãy thêm biến sau:
     - `GEMINI_API_KEY`: Mã khóa API của bạn từ [Google AI Studio](https://aistudio.google.com/app/apikey).
   - Vercel sẽ tự động nhận diện đây là dự án Vite và thực hiện lệnh `npm run build`.

## Chạy cục bộ (Local)

1. Cài đặt dependencies: `npm install`
2. Tạo file `.env` và thêm `GEMINI_API_KEY=your_api_key_here`
3. Chạy lệnh: `npm run dev`
