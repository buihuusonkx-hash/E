/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Upload, Select, Button, ConfigProvider, message, Card, 
  Typography, Divider, Checkbox, Modal, Input, Spin 
} from 'antd';
import { 
  InboxOutlined, SettingOutlined, FileTextOutlined, 
  CheckCircleOutlined, DownloadOutlined, KeyOutlined, RobotOutlined 
} from '@ant-design/icons';

// Các thư viện xử lý hiển thị và xuất file
import ReactMarkdown from 'react-markdown';
import { marked } from 'marked';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';

// Gemini SDK
import { GoogleGenAI } from "@google/genai";

const { Text } = Typography;

const App: React.FC = () => {
  // --- STATES ---
  const [subject, setSubject] = useState('Toán học');
  const [grade, setGrade] = useState('Lớp 12');
  const [isDigitalComp, setIsDigitalComp] = useState(true);
  const [isAI, setIsAI] = useState(false);
  
  const [lessonFileList, setLessonFileList] = useState<any[]>([]);
  const [ppctFileList, setPpctFileList] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  
  const [apiKey, setApiKey] = useState('');
  const [isConfigOpen, setIsConfigOpen] = useState(false);

  useEffect(() => {
    // Ưu tiên API Key từ environment variable nếu có, sau đó đến localStorage
    const envKey = process.env.GEMINI_API_KEY;
    const savedKey = localStorage.getItem('gemini_api_key');
    
    if (envKey && envKey !== 'MY_GEMINI_API_KEY' && envKey !== '') {
      setApiKey(envKey);
    } else if (savedKey) {
      setApiKey(savedKey);
    }
  }, []);

  const saveApiKey = () => {
    const input = document.getElementById('apiKeyInput') as HTMLInputElement;
    if (input && input.value.trim() !== '') {
      const key = input.value.trim();
      setApiKey(key);
      localStorage.setItem('gemini_api_key', key);
      setIsConfigOpen(false);
      message.success('Đã cấu hình API Key thành công!');
    } else {
      message.error('Vui lòng nhập API Key hợp lệ!');
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const processFile = async (file: File): Promise<any> => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'txt') {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve({ text: `\n--- Tài liệu: ${file.name} ---\n${e.target?.result}\n` });
        reader.onerror = () => reject(new Error('Lỗi đọc file TXT'));
        reader.readAsText(file);
      });
    } else if (ext === 'pdf') {
      const base64 = await fileToBase64(file);
      return { inlineData: { data: base64, mimeType: 'application/pdf' } };
    } else {
      throw new Error(`Định dạng ${ext} chưa hỗ trợ. Xin chuyển sang PDF.`);
    }
  };

  // --- XUẤT FILE WORD CÓ CÔNG THỨC TOÁN CHUẨN ---
  const handleDownloadWord = () => {
    if (!result) return;
    
    // Nâng cấp bộ nhận diện Toán học
    let mathBlocks: string[] = [];
    const protectMath = (text: string) => {
      let counter = 0;
      return text
        .replace(/\$\$(.*?)\$\$/gs, (match) => {
          mathBlocks[counter] = match;
          return `###MATH_BLOCK_${counter++}###`;
        })
        .replace(/\\\[(.*?)\\\]/gs, (match) => {
          mathBlocks[counter] = match;
          return `###MATH_BLOCK_${counter++}###`;
        })
        .replace(/\$(.*?)\$/g, (match) => {
          mathBlocks[counter] = match;
          return `###MATH_BLOCK_${counter++}###`;
        })
        .replace(/\\\((.*?)\\\)/g, (match) => {
          mathBlocks[counter] = match;
          return `###MATH_BLOCK_${counter++}###`;
        });
    };

    const textProtected = protectMath(result);
    // @ts-ignore
    let htmlContent = marked.parse(textProtected) as string;
    
    mathBlocks.forEach((math, i) => {
      htmlContent = htmlContent.replace(`###MATH_BLOCK_${i}###`, `<span style="font-family: 'Courier New', monospace; color: #d32f2f;">${math}</span>`);
    });
    
    const preHtml = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <meta charset='utf-8'>
      <title>Giáo Án Năng Lực Số</title>
      <style>
        @page { size: A4; margin: 2cm; }
        body { font-family: 'Times New Roman', Times, serif; font-size: 13pt; line-height: 1.4; color: #000; }
        h1, h2, h3 { color: #000; text-align: center; text-transform: uppercase; }
        table { border-collapse: collapse; width: 100%; margin: 10px 0; }
        th, td { border: 1px solid black; padding: 5px; vertical-align: top; }
        .math-hint { font-size: 10pt; color: #666; font-style: italic; }
      </style>
    </head>
    <body>
      <p class="math-hint">* Lưu ý: Các công thức toán học được để ở dạng mã LaTeX. Quý thầy cô có thể sử dụng phần mềm MathType (chọn Toggle TeX) để chuyển đổi sang ký hiệu toán học đẹp mắt.</p>`;
    const postHtml = "</body></html>";
    const fullHtml = preHtml + htmlContent + postHtml;

    const blob = new Blob(['\ufeff', fullHtml], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Giao_An_So_${subject}_${grade.replace(' ', '')}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    message.success('Đã xuất thành công file Word!');
  };

  // --- IN TRỰC TIẾP TỪ TRÌNH DUYỆT (ĐẸP NHẤT) ---
  const handlePrint = () => {
    const printContent = document.getElementById('printable-result');
    if (!printContent) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const katexCss = '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css">';
    const tailwindCss = '<script src="https://cdn.tailwindcss.com"></script>';
    
    printWindow.document.write(`
      <html>
        <head>
          <title>In Giáo Án - ${subject} ${grade}</title>
          ${katexCss}
          ${tailwindCss}
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700&family=Times+New+Roman&display=swap');
            body { 
              font-family: 'Times New Roman', serif; 
              padding: 20px;
              background: white;
            }
            @page { size: A4; margin: 2cm; }
            .markdown-body { font-size: 13pt; line-height: 1.6; color: black; }
            h1, h2, h3 { margin-top: 1.5em; margin-bottom: 0.5em; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin: 1em 0; }
            th, td { border: 1px solid black; padding: 8px; text-align: left; }
            blockquote { border-left: 4px solid #ccc; padding-left: 1em; font-style: italic; }
            .katex-display { margin: 1em 0; overflow-x: auto; overflow-y: hidden; }
          </style>
        </head>
        <body>
          <div class="markdown-body">
            ${printContent.innerHTML}
          </div>
          <script>
            window.onload = () => {
              setTimeout(() => {
                window.print();
                window.close();
              }, 1000);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // --- GỌI API GEMINI ---
  const handleGenerate = async () => {
    if (lessonFileList.length === 0) {
      message.warning('Vui lòng tải lên file Giáo án gốc (PDF/TXT)!');
      return;
    }
    if (!apiKey) {
      setIsConfigOpen(true);
      return;
    }

    setLoading(true);
    const msgKey = 'ai-process';
    message.loading({ content: `AI đang phân tích và xử lý môn ${subject} ${grade}...`, key: msgKey, duration: 0 });

    try {
      const ai = new GoogleGenAI({ apiKey });
      
      const promptText = `Bạn là chuyên gia giáo dục hàng đầu Việt Nam, chuyên biên soạn tài liệu chuẩn mực cho giáo viên.
      
      MỤC TIÊU TỐI THƯỢNG (KHÔNG ĐƯỢC VI PHẠM): 
      1. GIỮ NGUYÊN 100% TOÀN BỘ VĂN BẢN GỐC: Bạn phải chép lại y hệt từng câu, từng chữ, từng dấu phẩy của giáo án gốc. TUYỆT ĐỐI KHÔNG tóm tắt, KHÔNG lược bỏ, KHÔNG thay đổi cách diễn đạt của tài liệu gốc.
      2. CHỈ ĐƯỢC PHÉP CHÈN THÊM: Bạn chỉ được phép chèn thêm các đoạn nội dung về "Năng lực số & AI" vào các vị trí phù hợp trong cấu trúc hiện có.
      
      🔥 QUY TẮC TRÌNH BÀY CÔNG THỨC TOÁN HỌC 🔥:
      - Mọi ký hiệu/công thức toán học BẮT BUỘC phải bọc trong dấu $ (inline) hoặc $$ (block).
      - Sửa các ký hiệu bị lỗi font từ tài liệu gốc thành mã LaTeX chuẩn đẹp (ví dụ: phân số \\frac, căn thức \\sqrt, tích phân \\int...).
      
      HƯỚNG DẪN BỔ SUNG:
      - Tại phần "Mục tiêu": Chèn thêm mục "Năng lực số và AI".
      - Tại phần "Học liệu": Chèn thêm các công cụ số/AI (Canva, GeoGebra, ChatGPT, Padlet...).
      - Tại mỗi "Hoạt động học tập": Chèn thêm một đoạn gợi ý cách ứng dụng công cụ số/AI để triển khai hoạt động đó.
      - ĐÁNH DẤU NỔI BẬT: Mọi nội dung chèn thêm phải bắt đầu bằng: **[💡 BỔ SUNG NĂNG LỰC SỐ & AI]: ...**
      
      TRÌNH BÀY:
      - Trả về văn bản Markdown hoàn chỉnh bao gồm: Toàn bộ văn bản gốc (không thiếu một chữ) + Các đoạn chèn thêm.`;

      const parts: any[] = [{ text: promptText }];

      const lessonFile = lessonFileList[0].originFileObj;
      parts.push(await processFile(lessonFile));
      
      if (ppctFileList.length > 0) {
        const ppctFile = ppctFileList[0].originFileObj;
        parts.push(await processFile(ppctFile));
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts: parts }
      });
      const generatedText = response.text;
      
      setResult(generatedText || "Không có kết quả.");
      message.success({ content: 'Đã hoàn thành!', key: msgKey, duration: 3 });

    } catch (error: any) {
      message.error({ content: `Lỗi: ${error.message}`, key: msgKey, duration: 5 });
    } finally {
      setLoading(false);
    }
  };

  const handleBeforeUpload = (file: File) => {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'pdf' && ext !== 'txt') {
      message.error('Hệ thống chỉ nhận file PDF hoặc TXT.');
      return Upload.LIST_IGNORE;
    }
    return false;
  };

  return (
    <ConfigProvider theme={{ token: { colorPrimary: '#1d4ed8', borderRadius: 12, fontFamily: "'Inter', sans-serif" } }}>
      <div className="min-h-screen bg-slate-50 p-4 md:p-8">
        
        {/* TOP BANNER */}
        <div className="max-w-6xl mx-auto bg-gradient-to-r from-blue-700 to-indigo-800 text-white p-8 rounded-3xl shadow-2xl flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-black uppercase tracking-wider mb-2">Trợ Lý Giáo Án Số 4.0</h1>
            <p className="text-blue-100 font-medium">Tự động chèn Năng lực số & Xuất Word công thức chuẩn</p>
          </div>
          <Button size="large" icon={<SettingOutlined />} ghost className="rounded-full font-bold" onClick={() => setIsConfigOpen(true)}>
            Cấu hình API Key
          </Button>
        </div>

        {/* MAIN CONTENT */}
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 space-y-8">
            <Card className="shadow-lg border-none rounded-3xl" title={<span className="text-blue-800 font-black text-lg"><FileTextOutlined className="mr-2"/> THIẾT LẬP THÔNG TIN</span>}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">Môn học</label>
                  <Select className="w-full" value={subject} onChange={setSubject} size="large" showSearch>
                    {[
                      'Toán học', 'Tiếng Việt', 'Ngữ văn', 'Tiếng Anh', 
                      'Tự nhiên và Xã hội', 'Khoa học', 'Khoa học tự nhiên', 'Lịch sử và Địa lý', 
                      'Vật lý', 'Hóa học', 'Sinh học', 'Lịch sử', 'Địa lý', 
                      'Đạo đức', 'Giáo dục công dân', 'Giáo dục kinh tế và pháp luật', 
                      'Công nghệ', 'Tin học', 'Giáo dục thể chất', 'Âm nhạc', 'Mỹ thuật', 
                      'Hoạt động trải nghiệm', 'Giáo dục địa phương', 'Giáo dục quốc phòng và an ninh'
                    ].map(s => <Select.Option key={s} value={s}>{s}</Select.Option>)}
                  </Select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">Khối lớp</label>
                  <Select className="w-full" value={grade} onChange={setGrade} size="large" showSearch>
                    {[...Array(12)].map((_, i) => <Select.Option key={i} value={`Lớp ${i + 1}`}>{`Lớp ${i + 1}`}</Select.Option>)}
                  </Select>
                </div>
              </div>
              <Divider className="my-6" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Checkbox checked={isDigitalComp} onChange={e => setIsDigitalComp(e.target.checked)} className="font-bold text-blue-900 bg-blue-50 p-4 rounded-xl border border-blue-100">Tích hợp Năng lực số</Checkbox>
                <Checkbox checked={isAI} onChange={e => setIsAI(e.target.checked)} className="font-bold text-indigo-900 bg-indigo-50 p-4 rounded-xl border border-indigo-100">Sử dụng Trí tuệ nhân tạo (AI)</Checkbox>
              </div>
            </Card>

            <Card className="shadow-lg border-none rounded-3xl" title={<span className="text-blue-800 font-black text-lg"><InboxOutlined className="mr-2"/> TÀI LIỆU ĐẦU VÀO</span>}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Upload.Dragger className="rounded-2xl bg-slate-50" accept=".pdf,.txt" multiple={false} fileList={lessonFileList} beforeUpload={handleBeforeUpload} onChange={info => setLessonFileList([...info.fileList].slice(-1).map(f => ({...f, status: 'done', originFileObj: f.originFileObj})))} onRemove={() => setLessonFileList([])}>
                  <p className="ant-upload-drag-icon"><FileTextOutlined className="text-blue-500 text-4xl" /></p>
                  <p className="font-bold">Tải giáo án gốc (PDF/TXT)</p>
                  <Text type="danger" className="text-xs font-bold mt-1">BẮT BUỘC</Text>
                </Upload.Dragger>
                <Upload.Dragger className="rounded-2xl bg-slate-50" accept=".pdf,.txt" multiple={false} fileList={ppctFileList} beforeUpload={handleBeforeUpload} onChange={info => setPpctFileList([...info.fileList].slice(-1).map(f => ({...f, status: 'done', originFileObj: f.originFileObj})))} onRemove={() => setPpctFileList([])}>
                  <p className="ant-upload-drag-icon"><InboxOutlined className="text-indigo-400 text-4xl" /></p>
                  <p className="font-bold">Tải PPCT (PDF/TXT)</p>
                  <Text className="text-xs text-gray-500 mt-1">TÙY CHỌN</Text>
                </Upload.Dragger>
              </div>
            </Card>

            <div className="flex justify-center py-4">
              <Button type="primary" size="large" className={`h-16 px-8 rounded-full font-black text-base shadow-xl border-none ${loading ? 'bg-gray-400' : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:scale-105'}`} onClick={handleGenerate} disabled={loading} icon={loading ? <Spin /> : <RobotOutlined className="text-2xl" />}>
                {loading ? 'ĐANG BIÊN SOẠN...' : 'Bấm nút bắt đầu, đợi AI hoàn thành và tải trực tiếp file word về'}
              </Button>
            </div>

            {result && (
              <Card className="shadow-2xl border-2 border-green-500/20 rounded-3xl" title={<span className="text-green-700 font-black text-xl"><CheckCircleOutlined /> KẾT QUẢ</span>} extra={<Button type="text" danger onClick={() => setResult(null)}>Xóa</Button>}>
                <div className="prose prose-blue max-w-none bg-white p-8 rounded-2xl border border-slate-200 overflow-auto max-h-[700px]" id="printable-result">
                  {/* BỘ HIỂN THỊ CÔNG THỨC TOÁN HỌC TRÊN WEB */}
                  <div className="markdown-body">
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
                      {result}
                    </ReactMarkdown>
                  </div>
                </div>
                <div className="flex flex-wrap justify-center gap-4 mt-8">
                  <Button type="primary" size="large" icon={<DownloadOutlined />} className="h-12 px-10 rounded-full font-bold bg-blue-600 hover:bg-blue-500 border-none" onClick={handleDownloadWord}>
                    XUẤT FILE WORD (DÙNG MATHTYPE)
                  </Button>
                  <Button type="primary" size="large" icon={<CheckCircleOutlined />} className="h-12 px-10 rounded-full font-bold bg-green-600 hover:bg-green-500 border-none" onClick={handlePrint}>
                    IN TRỰC TIẾP (CHUẨN ĐẸP NHẤT)
                  </Button>
                </div>
              </Card>
            )}
          </div>

          <div className="space-y-8">
            <div className="bg-slate-800 text-white p-8 rounded-3xl shadow-xl">
              <h3 className="text-xl font-black mb-6 text-blue-400 border-b border-slate-700 pb-4">📋 HƯỚNG DẪN</h3>
              <ul className="space-y-6">
                <li className="flex gap-4"><div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-black text-blue-400 shrink-0">1</div><p className="text-sm mt-1">Cấu hình API Key từ AI Studio.</p></li>
                <li className="flex gap-4"><div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-black text-blue-400 shrink-0">2</div><p className="text-sm mt-1">Tải file PDF giáo án gốc lên.</p></li>
                <li className="flex gap-4"><div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-black text-white shrink-0">3</div><p className="text-sm mt-1">Bấm nút Bắt đầu, đợi AI hoàn thành và tải trực tiếp file Word về.</p></li>
              </ul>
            </div>
          </div>
        </div>

        <Modal title={<span className="text-xl font-black text-blue-800"><KeyOutlined /> Cấu hình Hệ thống AI</span>} open={isConfigOpen} onCancel={() => setIsConfigOpen(false)} footer={null} destroyOnClose centered>
          <div className="py-4">
            <Input.Password size="large" placeholder="Nhập API Key bắt đầu bằng AIzaSy..." defaultValue={apiKey} id="apiKeyInput" className="rounded-xl border-gray-300 mb-6" />
            <div className="flex justify-between items-center">
              <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-xs font-semibold text-blue-600 hover:underline">👉 Lấy API Key miễn phí tại đây</a>
              <div className="flex gap-3">
                <Button onClick={() => setIsConfigOpen(false)} className="rounded-full">Đóng</Button>
                <Button type="primary" onClick={saveApiKey} className="rounded-full bg-blue-600">Lưu cấu hình</Button>
              </div>
            </div>
          </div>
        </Modal>

      </div>
    </ConfigProvider>
  );
};

export default App;
